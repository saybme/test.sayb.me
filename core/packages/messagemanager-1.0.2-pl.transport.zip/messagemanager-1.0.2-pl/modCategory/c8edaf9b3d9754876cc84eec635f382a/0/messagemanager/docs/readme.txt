
MessageManager


Author: Bob Ray <https://bobsguides.com>
Copyright 2015-2018 Bob Ray

MessageManager allows user to read, create, and reply to MODX Manager messages in the front-end of your site. Messages can be sent to individual users, user groups, or all users. You can let users opt out of the message system based on User Group Membership.


Official Documentation: https://bobsguides.com/messagemanager-tutorial.html

Bugs and Feature Requests: https://github.com:BobRay/MessageManager

Questions: https://forums.modx.com

Created by MyComponent
